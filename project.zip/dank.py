import pygame, random, sys
from pygame.locals import *
import time

''' RUN AWAY: AP Computer Science Principles
    By: Angelin and David Kim
    October 22, 2016 '''


# variable name set ups
FPS = 40
tearSmol = 30
tearBig = 40
tearSlow = 2
tearFAST = 8
moreCrying = 6
angeSpeed = 5
screenWidth = 700
screenHeight = 600
textColor = (255, 255, 255)
background = (164, 164, 164)
black = (0, 0, 0)
GAMEDISPLAY = pygame.display.set_mode((700,600))



# ends game
def terminate():
    pygame.quit()
    sys.exit()

# ends game when certain key pressed
def waitForangeToPressKey():
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE: # pressing escape quits
                    terminate()
                return
                
# sets up game, the window, and the cursor
pygame.init()
pygame.font.init()
mainClock = pygame.time.Clock()
windowSurface = pygame.display.set_mode((screenWidth, screenHeight))
pygame.display.set_caption('AP Compter Science Principles Project')
pygame.mouse.set_visible(False)

# set up sounds
pygame.mixer.music.load('background.mp3')

# set up images
angeImage = pygame.image.load('ange.png')
angeRect = angeImage.get_rect()
tearImage = pygame.image.load('tear.png')
# set up fonts
title = pygame.font.Font('nice.ttf', 40)
font = pygame.font.Font('Munro.ttf', 40)

# displays rules of game and then starts game
def talk():
    drawText('RUNNING AWAY', title, windowSurface, (screenWidth / 4), (screenHeight / 3))
    drawText('By Angelin and Davd Kim', title, windowSurface, (screenWidth / 4.5) - 100, (screenHeight / 3) + 80)
    pygame.display.update()
    time.sleep(5)
    GAMEDISPLAY.fill(black)
    drawText('Angelin is too cool to cry.', font, windowSurface, (screenWidth / 4.5), (screenHeight /3))
    drawText('Tears give her crippling depression.', font, windowSurface, (screenWidth / 5) - 80, (screenHeight / 3) + 50)
    pygame.display.update()
    time.sleep(5)
    GAMEDISPLAY.fill(black)
    drawText('Help her run from her tears', font, windowSurface, (screenWidth / 5.5), (screenHeight / 3))
    drawText('(and her problems) by using your', font, windowSurface, (screenWidth / 4.5)-80, (screenHeight / 3)+50)
    drawText('mouse to move her around.', font, windowSurface, (screenWidth / 2.5) - 160, (screenHeight / 3)+ 100 )
    pygame.display.update()
    time.sleep(5)
    GAMEDISPLAY.fill(black)
    drawText('Alternatively, you can use', font, windowSurface, (screenWidth / 5.5), (screenHeight / 3))
    drawText('WASD instead of the mouse.', font, windowSurface, (screenWidth / 3.5)-80, (screenHeight / 3)+50)
    pygame.display.update()
    time.sleep(3)
    GAMEDISPLAY.fill(black)
    drawText('But it\'s hard to make it on', font, windowSurface, (screenWidth / 5.5), (screenHeight / 3))
    drawText('your own. Certain keys on your', font, windowSurface, (screenWidth / 4)-80, (screenHeight / 3)+50)
    drawText('keyboard will help you if you', font, windowSurface, (screenWidth / 2.5) - 160, (screenHeight / 3)+ 100 )
    drawText('can find them.', font, windowSurface, (screenWidth / 1.5) - 240, (screenHeight / 3)+ 150 )
    pygame.display.update()
    time.sleep(7)
    GAMEDISPLAY.fill(black)
    drawText('Good Luck!', font, windowSurface, (screenWidth / 2.5), (screenHeight / 3))
    drawText('[Press Any Key to Begin]', font, windowSurface, (screenWidth / 1.8) - 240, (screenHeight / 3)+ 150 )
    pygame.display.update()
    time.sleep(5)
    letsPlay()
    
# ends game when ange hits a tear   
def angeHasHittear(angeRect, tears):
    for b in tears:
        if angeRect.colliderect(b['rect']):
            return True
    return False

# writes the text on the screen
def drawText(text, font, surface, x, y):
    textobj = font.render(text, 1, textColor)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)
    
# all the actual game stuff
def letsPlay():
    highScore = 0
    while True:
        # set up the start of the game
        tears = []
        score = 0
        angeRect.topleft = (screenWidth / 2, screenHeight - 50)
        moveLeft = moveRight = moveUp = moveDown = False
        reverseCheat = slowCheat = False
        tearAddCounter = 0
        pygame.mixer.music.play(0, 0.0)
        waitForangeToPressKey()
    
        while True: # the game loop runs while the game part is playing
            score += 1 # increase score
    
            for event in pygame.event.get():
                if event.type == QUIT:
                    terminate()
    
                if event.type == KEYDOWN:
                    if event.key == ord('m'):
                        reverseCheat = True
                    if event.key == ord('y'):
                        slowCheat = True
                    if event.key == K_LEFT or event.key == ord('a'):
                        moveRight = False
                        moveLeft = True
                    if event.key == K_RIGHT or event.key == ord('d'):
                        moveLeft = False
                        moveRight = True
                    if event.key == K_UP or event.key == ord('w'):
                        moveDown = False
                        moveUp = True
                    if event.key == K_DOWN or event.key == ord('s'):
                        moveUp = False
                        moveDown = True
    
                if event.type == KEYUP:
                    if event.key == ord('m'):
                        reverseCheat = False
                        score = 0
                    if event.key == ord('y'):
                        slowCheat = False
                        score = 0
                    if event.key == K_ESCAPE:
                            terminate()
    
                    if event.key == K_LEFT or event.key == ord('a'):
                        moveLeft = False
                    if event.key == K_RIGHT or event.key == ord('d'):
                        moveRight = False
                    if event.key == K_UP or event.key == ord('w'):
                        moveUp = False
                    if event.key == K_DOWN or event.key == ord('s'):
                        moveDown = False
    
                if event.type == MOUSEMOTION:
                    # if the mouse moves, move ange where the cursor is
                    angeRect.move_ip(event.pos[0] - angeRect.centerx, event.pos[1] - angeRect.centery)
    
            # add new tears at the top of the screen
            if not reverseCheat and not slowCheat:
                tearAddCounter += 1
            if tearAddCounter == moreCrying:
                tearAddCounter = 0
                tearSize = random.randint(tearSmol, tearBig)
                newtear = {'rect': pygame.Rect(random.randint(0, screenWidth-tearSize), 0 - tearSize, tearSize, tearSize),
                            'speed': random.randint(tearSlow, tearFAST),
                            'surface':pygame.transform.scale(tearImage, (tearSize, tearSize)),
                            }
    
                tears.append(newtear)
    
            # move ange around
            if moveLeft and angeRect.left > 0:
                angeRect.move_ip(-1 * angeSpeed, 0)
            if moveRight and angeRect.right < screenWidth:
                angeRect.move_ip(angeSpeed, 0)
            if moveUp and angeRect.top > 0:
                angeRect.move_ip(0, -1 * angeSpeed)
            if moveDown and angeRect.bottom < screenHeight:
                angeRect.move_ip(0, angeSpeed)
    
            # moves the mouse cursor to match ange
            pygame.mouse.set_pos(angeRect.centerx, angeRect.centery)
    
            # moves the tears down
            for b in tears:
                if not reverseCheat and not slowCheat:
                    b['rect'].move_ip(0, b['speed'])
                elif reverseCheat:
                    b['rect'].move_ip(0, -5)
                elif slowCheat:
                    b['rect'].move_ip(0, 1)
    
            # deletes tears that have fallen past the bottom.
            for b in tears[:]:
                if b['rect'].top > screenHeight:
                    tears.remove(b)
    
            # adds background
            windowSurface.fill(background)
    
            # displays the score and top score.
            drawText('Score: %s' % (score), font, windowSurface, 10, 0)
            drawText('Top Score: %s' % (highScore), font, windowSurface, 10, 40)
    
            # draws ange's rectangle
            windowSurface.blit(angeImage, angeRect)
    
            # adds each tear
            for b in tears:
                windowSurface.blit(b['surface'], b['rect'])
    
            pygame.display.update()
    
            # checks if any of the tears have hit ange.
            if angeHasHittear(angeRect, tears):
                if score > highScore:
                    highScore = score # set new high score
                break
    
            mainClock.tick(FPS)
    
        # stops the game and displays GAME OVER
        pygame.mixer.music.stop()
    
        drawText('   GAME OVER', font, windowSurface, (screenWidth / 3), (screenHeight / 3))
        drawText('Press any key to play again.', font, windowSurface, (screenWidth / 3) - 80, (screenHeight / 3) + 50)
        pygame.display.update()
        waitForangeToPressKey()
      
# MAIN  
talk()

