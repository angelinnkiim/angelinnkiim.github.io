'''''''''''''''''''''''''''
Data Project
By Angelin Kim and Rucha Modi
Period 6
AP CSP 
'''''''''''''''''''''''''''

import matplotlib.pyplot as plt
import os.path

# Customizes the graph
def style(axes):
    for item in ([axes.title, axes.xaxis.label, axes.yaxis.label] +
             axes.get_xticklabels() + axes.get_yticklabels()):
        item.set_family('Ariel MS')
        item.set_fontsize(10)
        
directory = os.path.dirname(os.path.abspath(__file__))

# Build an absolute filename from directory + filename
debtfile = os.path.join(directory, 'debt.csv')
filename = os.path.join(directory, 'satisfaction2.csv')
confifile = os.path.join(directory, 'confidence.csv')
datafile = open(filename,'r')
datafile2 = open(debtfile, 'r')
datafile3 = open(confifile, 'r')
data = datafile.readlines()
data2 = datafile2.readlines()
data3 = datafile3.readlines()

#all the lists 
years = []
years2 = []
years3 = []
dollars = []
veryS = []
somewhatS = []
somewhatD = []
veryD = []
no = []
confidence = []

# Skips the first line of the data (titles)
for line in data[1:]:
    # Splits every individual part with a comma in the csv file
    year, verySat, somewhatSat, somewhatDis, veryDis, noOpinion = line.split(',')
    years.append(year)
    veryS.append(verySat)
    somewhatS.append(somewhatSat)
    somewhatD.append(somewhatDis)
    veryD.append(veryDis)
    no.append(noOpinion)
    datafile.close()
    
for line in data2[1:]:
    yearz, money = line.split(',')
    years2.append(yearz)
    dollars.append(money)
    datafile2.close()
    
for line in data3[1:]:
    yearzz, people = line.split(',')
    years3.append(yearzz)
    confidence.append(people)
    datafile3.close()
    
# Creates 3 graphs
fig_size, ax  = plt.subplots(1, 3)

# Plots the graphs and data
ax[0].plot(years, veryS, color = 'blue')
ax[0].plot(years, somewhatS, color = 'magenta')
ax[0].plot(years, somewhatD, color = 'orange')
ax[0].plot(years, veryD, color = 'green')
ax[0].plot(years, no, color = 'black')
ax[1].plot(years2, dollars, color = 'red')
ax[2].plot(years3, confidence, color = 'purple')

# Limits the x and y axes
ax[0].set_xlim(2001, 2016)
ax[0].set_ylim(0,100)
ax[1].set_xlim(1990, 2015)
ax[1].set_ylim(200000,750000)
ax[2].set_xlim(1990, 2016)
ax[2].set_ylim(0,100)

# Creates labels for the graphs
ax[0].set_title('Are you satisfied with our Military?')
ax[0].set_xlabel('Year')
ax[0].set_ylabel('Percentage')
ax[1].set_title('U.S. Military Spending')
ax[1].set_xlabel('Year')
ax[1].set_ylabel('USD (in millions)')
ax[2].set_title('Are you confident in our military?')
ax[2].set_xlabel('Year')
ax[2].set_ylabel('Percentage of Confident People')

#creates the legend for the lines
verys, = plt.plot([2,2,3], label='very satisfied', color='blue')
sws, = plt.plot([3,2,1], label='somewhat satisfied', color='magenta')
swd, = plt.plot([3,2,1], label='somewhat dissatisfied', color='orange')
veryd, = plt.plot([3,2,1], label='very dissatisfied', color='green')
noo, = plt.plot([3,2,1], label='no opinion', color='black')
ax[0].legend(handles=[verys, sws, swd, veryd, noo])

plt.show()